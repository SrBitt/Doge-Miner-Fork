# DogeMiner
This is a clone of Doge Miner
